import { IProduct } from "../home";

export type  TWishlist = {
    user_id: string;
    product_id: IProduct;
    created_at: string;
    _id: string;
}