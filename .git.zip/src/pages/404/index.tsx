import NotFoundComponent from "@/components/404";

const NotFound = () => {
  return <NotFoundComponent />;
};

export default NotFound;
