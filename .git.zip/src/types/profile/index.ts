export type CredentialForm = {
    password: string
    confirm_password: string
}