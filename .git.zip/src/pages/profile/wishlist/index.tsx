import WishlistComponent from "@/components/profile/wishlist";
const Wishlist = () => {
  return <WishlistComponent />;
};

export default Wishlist;
