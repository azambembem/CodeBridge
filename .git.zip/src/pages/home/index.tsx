//  pages dagi homelarimiz bizga routerlarga kerak
// import HomeComponent from "../../components/home";
import HomeComponent from "@/components/home"; // yani tepadagi ../../ bn bir xil ishlaydi..
const Home = () => {
  return (
    <div>
      <HomeComponent />
    </div>
  );
};

export default Home;
