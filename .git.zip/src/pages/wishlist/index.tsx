import WishlistComponent from "../../components/wishlist";
const Wishlist = () => {
  return <WishlistComponent />;
};

export default Wishlist;
