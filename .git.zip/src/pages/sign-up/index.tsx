import SignUpComponent from "@/components/sign-up";

const SignUp = () => {
  return <SignUpComponent />;
};

export default SignUp;
