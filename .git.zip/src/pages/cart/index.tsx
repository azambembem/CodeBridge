import CartComponent from "@/components/cart";
const Cart = () => {
  return <CartComponent />;
};

export default Cart;
