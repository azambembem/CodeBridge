import BillingComponent from "@/components/billing";

const Billing = () => {
  return <BillingComponent />;
};

export default Billing;
