import PaymentOptionsComponent from "@/components/profile/payment-options";

const PaymentOptions = () => {
  return <PaymentOptionsComponent />;
};

export default PaymentOptions;
