import AddressBookComponent from "@/components/profile/address-book";

const AddressBook = () => {
  return <AddressBookComponent />;
};

export default AddressBook;
