import AboutComponent from "@/components/about";

const About = () => {
  return <AboutComponent />;
};

export default About;
