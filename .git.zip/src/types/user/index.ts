export type TUser = {
    create_at: string,
    update_at: string,
    first_name: string,
    last_name: string,
    email: string,
    password: string,
    profile_picture: string
    _id: string,
    __v: 0
}