import SignInComponent from "@/components/sign-in";

const SignIn = () => {
  return <SignInComponent />;
};

export default SignIn;
