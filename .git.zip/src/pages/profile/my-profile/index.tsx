import MyProfileComponent from "@/components/profile/my-profile";

const MyProfile = () => {
  return <MyProfileComponent />;
};

export default MyProfile;
