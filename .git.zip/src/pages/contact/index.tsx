import ContactComponent from "@/components/contact";

const Contact = () => {
  return <ContactComponent />;
};

export default Contact;
