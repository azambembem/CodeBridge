import ProductComponent from "@/components/product";

const Product = () => {
	return <ProductComponent />;
};

export default Product;
