import ReturnsComponent from "@/components/profile/returns";

const Returns = () => {
  return <ReturnsComponent />;
};

export default Returns;
