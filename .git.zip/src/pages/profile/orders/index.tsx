import OrdersComponent from "@/components/profile/orders";

const Orders = () => {
  return <OrdersComponent />;
};

export default Orders;
